import React, { useState } from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  lightText?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  showTagline = false,
  lightText = false,
}) => {
  const [imageError, setImageError] = useState(false);

  // Height / dimension scaling
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-14 h-14 md:w-16 md:h-16',
    lg: 'w-20 h-20 md:w-24 md:h-24',
    xl: 'w-28 h-28 md:w-32 md:h-32',
  }[size];

  return (
    <div className={`flex items-center gap-3.5 ${className}`}>
      {/* Logo container preserving exact 1:1 proportion and rounded white badge so colors pop on dark backgrounds */}
      <div
        className={`${sizeClasses} shrink-0 relative rounded-xl bg-white p-1 shadow-sm border border-white/20 flex items-center justify-center overflow-hidden transition-transform duration-200 hover:scale-[1.02]`}
        title="Sinergy Travel and Business"
      >
        {!imageError ? (
          <img
            src="/IMG-20261012-WA4092.jpg"
            alt="Sinergy Travel and Business Logo"
            className="w-full h-full object-contain"
            onError={() => setImageError(true)}
          />
        ) : (
          /* High-fidelity Vector Representation precisely reproducing the user's uploaded official logo */
          <svg
            viewBox="0 0 200 200"
            className="w-full h-full"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-label="Sinergy Travel and Business"
          >
            {/* Green Mountain Summit (Official Brand Green #258A48 / #4CAF50) */}
            <path
              d="M20 78 L58 64 L74 38 L98 24 L108 30 L118 42 L138 52 L158 70 L174 64 L180 74 L170 76 L156 82 L132 58 L114 46 L102 36 L94 40 L72 58 L54 74 L32 78 Z"
              fill="#258A48"
            />
            {/* Mountain Ridge Accent */}
            <path
              d="M74 38 L98 24 L108 30 L118 42 L138 52 L158 70"
              stroke="#146438"
              strokeWidth="2.5"
              strokeLinejoin="round"
            />
            
            {/* Outer Blue Cradle Arc (#35A9E8) */}
            <path
              d="M36 78 C28 92 24 108 26 126 C29 146 44 168 68 180 C84 188 116 188 132 180 C156 168 171 146 174 126 C176 108 172 92 164 78 C160 86 156 128 136 150 C122 164 96 166 76 156 C52 144 42 110 36 78 Z"
              fill="#35A9E8"
            />

            {/* Warm Brown Cupping Hand (#8D5338) */}
            <path
              d="M44 106 C50 102 62 102 76 106 C92 110 114 116 128 116 C136 116 148 108 144 100 C140 94 130 96 122 98 C108 100 88 98 74 94 C60 90 48 94 44 106 Z"
              fill="#8D5338"
            />
            <path
              d="M48 104 C64 106 82 112 102 118 C116 122 134 124 142 116 C146 112 148 106 142 102 C132 108 116 110 102 106 C84 102 66 98 48 104 Z"
              fill="#A05C3B"
            />

            {/* Blue Commercial Airplane Silhouette (#29A8EC) climbing upwards */}
            <g transform="translate(68, 72) rotate(-8) scale(0.68)">
              {/* Aircraft fuselage and wings */}
              <path
                d="M10 24 C14 23 48 18 82 12 C96 9 106 14 102 20 C98 24 88 28 66 32 L88 48 L76 50 L56 36 L34 40 L38 52 L30 53 L24 42 C18 43 12 43 6 42 C2 41 -2 36 2 30 C4 27 6 25 10 24 Z"
                fill="#35A9E8"
              />
              {/* Vertical stabilizer and tail wing */}
              <path
                d="M4 25 L-6 0 L8 2 L14 20 Z"
                fill="#35A9E8"
              />
              {/* Engine nacelle */}
              <path
                d="M52 35 C52 32 58 31 64 31 C68 31 70 33 69 36 C68 39 62 40 56 40 C53 40 52 38 52 35 Z"
                fill="#2487BE"
              />
            </g>

            {/* Sinergy Brand Text Along Lower Curve */}
            <text
              x="100"
              y="188"
              textAnchor="middle"
              fill="#075B91"
              fontSize="12.5"
              fontWeight="800"
              fontFamily="system-ui, -apple-system, sans-serif"
              letterSpacing="0.05em"
            >
              Sinergy Travel and Business
            </text>
          </svg>
        )}
      </div>

      {/* Brand Wordmark & Tagline */}
      <div className="flex flex-col">
        <span
          className={`font-display font-extrabold tracking-tight leading-tight ${
            size === 'sm'
              ? 'text-sm'
              : size === 'lg' || size === 'xl'
              ? 'text-xl md:text-2xl'
              : 'text-base md:text-lg'
          } ${lightText ? 'text-white' : 'text-[#073B66]'}`}
        >
          Sinergy Travel & Business
        </span>
        {showTagline && (
          <span
            className={`text-xs italic font-medium leading-none mt-1 ${
              lightText ? 'text-[#35A9E8]' : 'text-[#258A48]'
            }`}
          >
            « Des professionnels à votre service »
          </span>
        )}
      </div>
    </div>
  );
};
