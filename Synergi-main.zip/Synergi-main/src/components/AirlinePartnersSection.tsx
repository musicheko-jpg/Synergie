import React from 'react';
import { Plane, Globe2, ShieldCheck } from 'lucide-react';
import { AIRLINE_PARTNERS } from '../data/travelData.ts';

export const AirlinePartnersSection: React.FC = () => {
  return (
    <section id="partenaires" className="py-20 bg-white border-t border-slate-200/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#075B91]/10 text-[#075B91] text-xs font-bold uppercase tracking-wider mb-3">
            <Globe2 className="w-3.5 h-3.5 text-[#258A48]" />
            <span>RÉSEAU AÉRIEN MONDIAL</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#073B66] tracking-tight mb-4">
            Compagnies aériennes et partenaires de vol
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Nous émettons vos billets et gérons vos réservations auprès des plus grandes compagnies régionales et internationales opérant au départ du Cameroun.
          </p>
        </div>

        {/* Airline Partners Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {AIRLINE_PARTNERS.map((partner) => (
            <div
              key={partner.id}
              className="p-5 rounded-2xl bg-[#F6F8FA] border border-slate-200/80 hover:border-[#35A9E8] hover:bg-white hover:shadow-lg transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#073B66] text-white flex items-center justify-center font-bold text-xs shadow-sm">
                    {partner.code}
                  </div>
                  {partner.alliance && (
                    <span className="text-[11px] font-semibold text-[#075B91] bg-[#EAF5FC] px-2.5 py-1 rounded-md border border-[#35A9E8]/30">
                      {partner.alliance}
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-[#073B66] mb-1">
                  {partner.name}
                </h3>

                <p className="text-xs text-slate-500 mb-2">
                  <span className="font-medium text-slate-700">Hub :</span> {partner.hub}
                </p>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {partner.note}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center gap-1.5 text-[11px] font-medium text-[#258A48]">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Réservation directe en agence</span>
              </div>
            </div>
          ))}

          {/* Additional Partner Card highlighting global connectivity */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#073B66] to-[#075B91] text-white flex flex-col justify-between shadow-md">
            <div>
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#35A9E8] mb-3">
                <Plane className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">
                Toutes autres compagnies
              </h3>
              <p className="text-xs text-[#EAF5FC]/90 leading-relaxed">
                Besoin d'une compagnie spécifique pour l'Amérique, l'Asie ou l'Afrique ? Notre système GDS billetterie accède à l'ensemble des transporteurs IATA.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/15 text-[11px] text-[#35A9E8] font-medium">
              Vols réguliers & charters sur demande
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
