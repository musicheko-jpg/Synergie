import React from 'react';
import { Phone, Mail, MapPin, ArrowUp, Globe, Shield } from 'lucide-react';
import { BrandLogo } from './BrandLogo.tsx';
import { AGENCY_CONTACT, SERVICES_DATA } from '../data/travelData.ts';

interface FooterProps {
  onSelectService: (serviceId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectService }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#102A43] text-white pt-16 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-12 border-b border-white/10">
          {/* Brand & Description (Col 1-4) */}
          <div className="lg:col-span-4 space-y-4">
            <BrandLogo size="md" lightText={true} showTagline={true} />
            <p className="text-xs text-[#EAF5FC]/80 leading-relaxed max-w-sm mt-3">
              Agence de voyage et de tourisme basée à Yaoundé, Cameroun. Accompagnement rigoureux des particuliers et des professionnels pour tous leurs déplacements nationaux et internationaux.
            </p>
            <div className="pt-2 text-xs text-[#35A9E8] flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#258A48]" />
              <span>Assistance & conseils sur mesure</span>
            </div>
          </div>

          {/* Quick Nav Links (Col 5-6) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white/50">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs text-[#EAF5FC]/85">
              <li>
                <a href="#accueil" className="hover:text-[#35A9E8] transition-colors">
                  Accueil
                </a>
              </li>
              <li>
                <a href="#a-propos" className="hover:text-[#35A9E8] transition-colors">
                  À propos de nous
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#35A9E8] transition-colors">
                  Nos services
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-[#35A9E8] transition-colors">
                  Destinations
                </a>
              </li>
              <li>
                <a href="#partenaires" className="hover:text-[#35A9E8] transition-colors">
                  Compagnies aériennes
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#35A9E8] transition-colors">
                  Contact & Devis
                </a>
              </li>
            </ul>
          </div>

          {/* Core Services Quick Access (Col 7-9) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white/50">
              Services populaires
            </h4>
            <ul className="space-y-2 text-xs text-[#EAF5FC]/85">
              {SERVICES_DATA.slice(0, 6).map((service) => (
                <li key={service.id}>
                  <button
                    onClick={() => {
                      onSelectService(service.id);
                      document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="hover:text-[#35A9E8] transition-colors text-left"
                  >
                    {service.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details (Col 10-12) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white/50">
              Nous contacter
            </h4>
            <div className="space-y-2.5 text-xs text-[#EAF5FC]/85">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#258A48] shrink-0 mt-0.5" />
                <span>{AGENCY_CONTACT.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#35A9E8] shrink-0" />
                <div className="flex flex-col">
                  {AGENCY_CONTACT.phones.map((p) => (
                    <a key={p.raw} href={`tel:${p.raw}`} className="hover:text-white transition-colors">
                      {p.display}
                    </a>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#35A9E8] shrink-0" />
                <a href={`mailto:${AGENCY_CONTACT.email}`} className="hover:text-white transition-colors">
                  {AGENCY_CONTACT.email}
                </a>
              </div>
              <div className="pt-2 text-[11px] text-white/60">
                {AGENCY_CONTACT.hours}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/60">
          <p>
            © {new Date().getFullYear()} Sinergy Travel and Business. Tous droits réservés. Yaoundé, Cameroun.
          </p>
          <div className="flex items-center gap-4">
            <span className="italic text-[#35A9E8]">
              « Des professionnels à votre service »
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors flex items-center gap-1.5 focus:outline-none"
              title="Retour en haut de page"
            >
              <span>Haut de page</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
