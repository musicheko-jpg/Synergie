import React from 'react';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  MessageCircle,
  HelpCircle,
  ShieldCheck,
  Building2,
  CalendarCheck,
} from 'lucide-react';
import { AGENCY_CONTACT } from '../data/travelData.ts';

export const ContactSection: React.FC = () => {
  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#F6F8FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#073B66]/10 text-[#073B66] text-xs font-bold uppercase tracking-wider mb-3">
            <span className="w-2 h-2 rounded-full bg-[#258A48]" />
            <span>CONTACT & INFORMATIONS DE L'AGENCE</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#073B66] tracking-tight mb-4">
            Contactez Sinergy Travel and Business
          </h2>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Notre équipe est à votre disposition pour échanger sur vos besoins et vous accompagner dans la préparation de votre voyage.
          </p>
        </div>

        {/* Contact Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {/* Card 1: Téléphones & WhatsApp */}
          <div className="bg-white rounded-2xl p-8 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-[#073B66]/10 text-[#073B66] flex items-center justify-center mb-6">
                <Phone className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-[#073B66] mb-2">
                Téléphones & WhatsApp
              </h3>
              <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                Joignez directement nos agents de voyage pour vos réservations et questions urgentes.
              </p>
              <div className="space-y-3">
                {AGENCY_CONTACT.phones.map((phone) => (
                  <div key={phone.raw} className="flex items-center justify-between p-3 rounded-xl bg-[#F6F8FA] border border-slate-200/70">
                    <span className="text-xs text-slate-500">Ligne directe</span>
                    <a
                      href={`tel:${phone.raw}`}
                      className="font-bold text-sm text-[#073B66] hover:text-[#35A9E8] transition-colors"
                    >
                      {phone.display}
                    </a>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100">
              <a
                href={`https://wa.me/${AGENCY_CONTACT.whatsappNumber}?text=Bonjour%20Sinergy%20Travel,%20je%20souhaite%20des%20informations%20sur%20vos%20services.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2.5 px-4 py-3 rounded-xl bg-[#258A48] hover:bg-[#146438] text-white text-sm font-semibold transition-all duration-200 shadow-sm cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Discuter sur WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Card 2: E-mail & Correspondance */}
          <div className="bg-white rounded-2xl p-8 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-[#075B91]/10 text-[#075B91] flex items-center justify-center mb-6">
                <Mail className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-[#073B66] mb-2">
                E-mail & Devis écrits
              </h3>
              <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                Transmettez vos demandes de cotation pour groupes, entreprises ou voyages individuels.
              </p>
              <div className="p-4 rounded-xl bg-[#F6F8FA] border border-slate-200/70 mb-4">
                <span className="block text-xs text-slate-500 mb-1">Courriel officiel</span>
                <a
                  href={`mailto:${AGENCY_CONTACT.email}`}
                  className="font-bold text-sm text-[#073B66] hover:text-[#35A9E8] transition-colors break-all"
                >
                  {AGENCY_CONTACT.email}
                </a>
              </div>
              <div className="p-4 rounded-xl bg-[#EAF5FC] border border-[#35A9E8]/30 text-xs text-[#073B66] leading-relaxed">
                <span className="font-semibold block mb-1">Traitement réactif :</span>
                Réponse sous 24h ouvrées avec propositions tarifaires et disponibilités.
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100">
              <a
                href={`mailto:${AGENCY_CONTACT.email}?subject=Demande%20d'information%20voyage%20-%20Sinergy%20Travel`}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#073B66] hover:bg-[#075B91] text-white text-sm font-semibold transition-all duration-200 shadow-sm cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>Envoyer un courriel</span>
              </a>
            </div>
          </div>

          {/* Card 3: Adresse & Horaires */}
          <div className="bg-white rounded-2xl p-8 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-[#258A48]/10 text-[#258A48] flex items-center justify-center mb-6">
                <MapPin className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-[#073B66] mb-2">
                Agence à Yaoundé
              </h3>
              <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                Rencontrez nos conseillers dans nos locaux à Yaoundé pour un accompagnement personnalisé.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-[#F6F8FA] border border-slate-200/70">
                  <Building2 className="w-4 h-4 text-[#258A48] shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-xs text-slate-500">Adresse</span>
                    <span className="text-xs font-semibold text-[#102A43]">
                      {AGENCY_CONTACT.address}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-[#F6F8FA] border border-slate-200/70">
                  <Clock className="w-4 h-4 text-[#35A9E8] shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-xs text-slate-500">Horaires d'ouverture</span>
                    <span className="text-xs font-semibold text-[#102A43]">
                      {AGENCY_CONTACT.hours}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100 flex items-center gap-2 text-xs font-medium text-[#258A48]">
              <ShieldCheck className="w-4 h-4" />
              <span>Accueil physique et conseil sur rendez-vous</span>
            </div>
          </div>
        </div>

        {/* Agency Commitment Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-[#073B66] via-[#075B91] to-[#073B66] text-white p-8 lg:p-10 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl text-center lg:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#35A9E8] mb-2">
              <CalendarCheck className="w-4 h-4" />
              <span>Sinergy Travel and Business</span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">
              « {AGENCY_CONTACT.tagline} »
            </h3>
            <p className="text-sm text-[#EAF5FC]/90 leading-relaxed">
              Pour réserver vos billets d'avion, organiser vos hébergements ou préparer vos démarches de visa, contactez directement nos conseillers par téléphone ou WhatsApp.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
            <a
              href={`tel:${AGENCY_CONTACT.phones[0].raw}`}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white text-[#073B66] hover:bg-[#EAF5FC] text-sm font-bold shadow-md transition-colors"
            >
              <Phone className="w-4 h-4 text-[#075B91]" />
              <span>Appeler l'agence</span>
            </a>

            <a
              href={`https://wa.me/${AGENCY_CONTACT.whatsappNumber}?text=Bonjour%20Sinergy%20Travel,%20je%20souhaite%20un%20accompagnement%20pour%20mon%20voyage.`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#258A48] hover:bg-[#35A9E8] text-white text-sm font-bold shadow-md transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Message WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
