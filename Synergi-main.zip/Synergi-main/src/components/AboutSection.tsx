import React from 'react';
import { ArrowRight, CheckCircle2, Award, Users } from 'lucide-react';
import aboutImage from '../assets/images/about_traveler_terminal_1791865533721.jpg';

interface AboutSectionProps {
  onLearnMoreClick: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onLearnMoreClick }) => {
  return (
    <section id="a-propos" className="py-20 lg:py-28 bg-[#F6F8FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Travel Photograph */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl shadow-black/10 border border-slate-200/80 aspect-[4/3]">
              <img
                src={aboutImage}
                alt="Voyageuse professionnelle en salle d'embarquement face aux avions"
                className="w-full h-full object-cover"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              {/* Subtle gradient vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#073B66]/40 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Floating Brand Badge / Trust mark */}
            <div className="absolute -bottom-6 -right-3 sm:right-6 bg-white rounded-xl p-4 shadow-xl border border-slate-100 flex items-center gap-3.5 max-w-xs">
              <div className="w-11 h-11 rounded-lg bg-[#258A48]/10 text-[#258A48] flex items-center justify-center shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-[#073B66] uppercase tracking-wider">
                  Agence à Yaoundé
                </p>
                <p className="text-xs text-slate-600 mt-0.5">
                  Des professionnels dédiés à la réussite de votre voyage.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Copy */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            {/* Tagline / Subtitle */}
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#075B91] mb-3">
              <span className="w-2 h-2 rounded-full bg-[#258A48]" />
              <span>À PROPOS DE NOTRE AGENCE</span>
            </div>

            {/* Heading */}
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#073B66] tracking-tight leading-tight mb-6">
              Bien plus qu'un voyage,{' '}
              <span className="text-[#075B91]">un accompagnement.</span>
            </h2>

            {/* Paragraphs */}
            <p className="text-base text-[#102A43]/85 leading-relaxed mb-4">
              Sinergy Travel and Business accompagne les particuliers et les professionnels dans la préparation de leurs déplacements. Nous proposons plusieurs services pour vous aider à organiser votre voyage, de la réservation de billets d'avion à la préparation de circuits touristiques.
            </p>

            <p className="text-base text-[#102A43]/85 leading-relaxed mb-8">
              Que vous voyagiez pour le travail, le tourisme ou une occasion spéciale, notre objectif est de vous aider à préparer votre projet et à trouver les solutions adaptées à vos besoins.
            </p>

            {/* Key benefits list with subtle green accents */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mb-8 text-sm font-medium text-[#102A43]">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#258A48] shrink-0" />
                <span>Billetterie toutes compagnies</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#258A48] shrink-0" />
                <span>Conseils visa & démarches</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#258A48] shrink-0" />
                <span>Voyages d'affaires & vacances</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#258A48] shrink-0" />
                <span>Interlocuteur unique & dédié</span>
              </div>
            </div>

            {/* CTA Button */}
            <div>
              <button
                onClick={onLearnMoreClick}
                className="inline-flex items-center gap-2.5 px-6 py-3 rounded-lg text-sm font-semibold text-white bg-[#073B66] hover:bg-[#075B91] active:scale-[0.98] shadow-sm transition-all duration-200 cursor-pointer"
              >
                <span>En savoir plus sur nos services</span>
                <ArrowRight className="w-4 h-4 text-[#35A9E8]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
