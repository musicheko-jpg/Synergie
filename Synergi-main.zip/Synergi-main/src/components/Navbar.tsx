import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, CalendarCheck } from 'lucide-react';
import { BrandLogo } from './BrandLogo.tsx';
import { AGENCY_CONTACT } from '../data/travelData.ts';

interface NavbarProps {
  onPlanTripClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onPlanTripClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Accueil', href: '#accueil' },
    { label: 'À propos', href: '#a-propos' },
    { label: 'Nos services', href: '#services' },
    { label: 'Destinations', href: '#destinations' },
    { label: 'Partenaires', href: '#partenaires' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#073B66]/95 backdrop-blur-md shadow-lg shadow-black/15 py-2.5 border-b border-white/10'
          : 'bg-[#073B66] py-3.5 border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6">
          {/* Official Company Logo */}
          <a
            href="#accueil"
            className="focus:outline-none focus-visible:ring-2 focus-visible:ring-[#35A9E8] rounded-xl"
            aria-label="Sinergy Travel and Business - Accueil"
          >
            <BrandLogo size="md" lightText={true} showTagline={true} />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="text-sm font-medium text-white/90 hover:text-[#35A9E8] transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 hover:after:w-full after:h-0.5 after:bg-[#35A9E8] after:transition-all after:duration-200 whitespace-nowrap shrink-0"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* CTA & Direct Phone */}
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <a
              href={`tel:${AGENCY_CONTACT.phones[0].raw}`}
              className="hidden xl:flex items-center gap-2 text-xs font-semibold text-white/80 hover:text-white transition-colors"
              title="Appeler notre agence"
            >
              <span className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-[#35A9E8]">
                <Phone className="w-4 h-4" />
              </span>
              <span className="whitespace-nowrap">{AGENCY_CONTACT.phones[0].display}</span>
            </a>

            <button
              onClick={onPlanTripClick}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold text-white bg-[#258A48] hover:bg-[#35A9E8] active:scale-[0.98] shadow-md shadow-black/10 transition-all duration-200 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#35A9E8] cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Planifier mon voyage</span>
            </button>
          </div>

          {/* Mobile Hamburger Toggle Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-lg text-white hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#35A9E8]"
              aria-expanded={isMobileMenuOpen}
              aria-label={isMobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-white" />
              ) : (
                <Menu className="w-6 h-6 text-white" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#073B66] border-b border-white/10 px-4 pt-3 pb-6 shadow-xl animate-fadeIn">
          <div className="flex flex-col space-y-2.5 mb-5">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="px-3 py-2 rounded-lg text-base font-medium text-white/95 hover:bg-white/10 hover:text-[#35A9E8] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-3">
            <div className="flex items-center gap-2.5 px-3 text-xs text-white/70">
              <Phone className="w-4 h-4 text-[#35A9E8]" />
              <span>{AGENCY_CONTACT.phones[0].display}</span>
              <span>·</span>
              <span>Yaoundé</span>
            </div>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onPlanTripClick();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg text-sm font-semibold text-white bg-[#258A48] hover:bg-[#35A9E8] transition-colors shadow-md"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Planifier mon voyage</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
