import React from 'react';
import { MessageSquareText, PhoneCall, Sparkles } from 'lucide-react';
import ctaBgImage from '../assets/images/cta_coastal_paradise_1791865562204.jpg';
import { AGENCY_CONTACT } from '../data/travelData.ts';

interface CallToActionSectionProps {
  onDiscussProjectClick: () => void;
}

export const CallToActionSection: React.FC<CallToActionSectionProps> = ({
  onDiscussProjectClick,
}) => {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden bg-[#073B66]">
      {/* Background coastal resort photograph */}
      <div className="absolute inset-0 z-0">
        <img
          src={ctaBgImage}
          alt="Complexe touristique et lagon turquoise"
          className="w-full h-full object-cover filter brightness-[0.88]"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        {/* Subtle deep-blue overlay preserving photography */}
        <div className="absolute inset-0 bg-[#073B66]/70 backdrop-blur-[1px]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#073B66] via-transparent to-[#073B66]/60" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        {/* Subtle badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-[#35A9E8] text-xs font-bold uppercase tracking-wider mb-6">
          <Sparkles className="w-4 h-4 text-[#35A9E8]" />
          <span>VOTRE PROJET DE VOYAGE SUR MESURE</span>
        </div>

        {/* Main Heading */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-6 leading-tight">
          Prêt à préparer votre prochain voyage ?
        </h2>

        {/* Supporting text */}
        <p className="text-base sm:text-lg lg:text-xl text-[#EAF5FC]/95 font-normal leading-relaxed max-w-2xl mx-auto mb-10">
          Parlez-nous de votre projet et découvrez les services qui peuvent vous accompagner dans votre voyage.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onDiscussProjectClick}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl text-base font-semibold text-white bg-[#258A48] hover:bg-[#35A9E8] active:scale-[0.98] shadow-xl shadow-black/20 transition-all duration-200 cursor-pointer"
          >
            <MessageSquareText className="w-5 h-5" />
            <span>Discuter de mon projet</span>
          </button>

          <a
            href={`tel:${AGENCY_CONTACT.phones[0].raw}`}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl text-base font-semibold text-white bg-white/10 hover:bg-white hover:text-[#073B66] border border-white/25 backdrop-blur-sm transition-all duration-200"
          >
            <PhoneCall className="w-5 h-5" />
            <span>Appel direct : {AGENCY_CONTACT.phones[0].display}</span>
          </a>
        </div>
      </div>
    </section>
  );
};
