import React from 'react';
import { Plane, Compass, ArrowRight, ShieldCheck, MapPin } from 'lucide-react';
import heroImage from '../assets/images/hero_airplane_travel_1791865532267.jpg';

interface HeroSectionProps {
  onReserveFlightClick: () => void;
  onDiscoverServicesClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onReserveFlightClick,
  onDiscoverServicesClick,
}) => {
  return (
    <section
      id="accueil"
      className="relative min-h-[580px] lg:min-h-[660px] flex items-center overflow-hidden bg-[#073B66]"
    >
      {/* Background Airplane Travel Photograph */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Avion de ligne survolant une destination internationale ensoleillée"
          className="w-full h-full object-cover object-center lg:object-right filter brightness-[0.92]"
          loading="eager"
          referrerPolicy="no-referrer"
        />
        {/* Measured Deep-Blue Gradient Overlay: keeps image visible on right while guaranteeing contrast for text on left */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#073B66]/95 via-[#073B66]/80 to-[#073B66]/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#073B66]/80 via-transparent to-transparent lg:hidden" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="max-w-2xl lg:max-w-3xl">
          {/* Introductory Kicker */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-white/10 backdrop-blur-sm border border-white/15 text-[#EAF5FC] text-xs font-semibold tracking-wider uppercase mb-5">
            <span className="w-2 h-2 rounded-full bg-[#35A9E8]" />
            <span>VOTRE PARTENAIRE VOYAGE AU CAMEROUN</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-extrabold text-white tracking-tight leading-[1.12] mb-6 text-balance">
            Le monde vous attend.{' '}
            <span className="text-[#35A9E8]">Voyagez avec Sinergy.</span>
          </h1>

          {/* Supporting Paragraph */}
          <p className="text-base sm:text-lg lg:text-xl text-[#EAF5FC]/95 font-normal leading-relaxed mb-9 max-w-2xl">
            Billets d'avion, réservations d'hôtels, assistance visa, assurance voyage et circuits touristiques : nous vous accompagnons dans la préparation de vos déplacements.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <button
              onClick={onReserveFlightClick}
              className="inline-flex items-center justify-center gap-3 px-7 py-3.5 rounded-lg text-base font-semibold text-white bg-[#258A48] hover:bg-[#35A9E8] active:scale-[0.98] shadow-lg shadow-black/20 transition-all duration-200 cursor-pointer group"
            >
              <Plane className="w-5 h-5 transition-transform group-hover:translate-x-0.5" />
              <span>Réserver un billet d'avion</span>
            </button>

            <button
              onClick={onDiscoverServicesClick}
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-lg text-base font-semibold text-white bg-white/10 hover:bg-white hover:text-[#073B66] border border-white/30 backdrop-blur-sm transition-all duration-200 cursor-pointer"
            >
              <Compass className="w-5 h-5" />
              <span>Découvrir nos services</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Micro trust indicators */}
          <div className="mt-10 pt-6 border-t border-white/15 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-[#EAF5FC]/80">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#35A9E8]" />
              <span>Agence agréée à Yaoundé</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#258A48]" />
              <span>Départs Cameroun & Monde entier</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-white font-medium">« Des professionnels à votre service »</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
