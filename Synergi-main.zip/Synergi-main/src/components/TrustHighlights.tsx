import React from 'react';
import { Headset, Compass, ShieldCheck, MapPin } from 'lucide-react';
import { TRUST_HIGHLIGHTS } from '../data/travelData.ts';

const iconMap: Record<string, React.ReactNode> = {
  Headset: <Headset className="w-6 h-6 text-[#35A9E8]" />,
  Compass: <Compass className="w-6 h-6 text-[#35A9E8]" />,
  ShieldCheck: <ShieldCheck className="w-6 h-6 text-[#258A48]" />,
  MapPin: <MapPin className="w-6 h-6 text-[#35A9E8]" />,
};

export const TrustHighlights: React.FC = () => {
  return (
    <section className="bg-[#102A43] text-white py-8 border-b border-white/10 shadow-inner">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-white/10">
          {TRUST_HIGHLIGHTS.map((item, index) => (
            <div
              key={item.id}
              className={`flex items-start gap-4 py-4 sm:py-2 ${
                index === 0 ? 'sm:pl-0 sm:pr-6' : index === TRUST_HIGHLIGHTS.length - 1 ? 'sm:pl-6 sm:pr-0' : 'sm:px-6'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center shrink-0 border border-white/10">
                {iconMap[item.icon]}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white tracking-tight leading-snug">
                  {item.title}
                </h3>
                <p className="text-xs text-[#EAF5FC]/75 mt-1 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
