import React, { useState } from 'react';
import {
  PlaneTakeoff,
  CalendarDays,
  Building2,
  Shield,
  FileCheck2,
  Coins,
  Car,
  Map,
  HeartHandshake,
  Sparkles,
  ChevronDown,
  ArrowRight,
  Check,
} from 'lucide-react';
import { SERVICES_DATA, ServiceItem } from '../data/travelData.ts';

interface ServicesSectionProps {
  onSelectService: (serviceId: string) => void;
}

const serviceIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  PlaneTakeoff,
  CalendarDays,
  Building2,
  Shield,
  FileCheck2,
  Coins,
  Car,
  Map,
  HeartHandshake,
  Sparkles,
};

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  // Set of service IDs currently expanded (persists when clicked/locked)
  const [lockedExpanded, setLockedExpanded] = useState<Record<string, boolean>>({
    'billets-avion': true, // Expanded by default to show rich affordance
  });
  // Track currently hovered card on desktop
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);

  const toggleLock = (id: string) => {
    setLockedExpanded((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const isExpanded = (id: string) => {
    return Boolean(lockedExpanded[id] || hoveredCardId === id);
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-[#EAF5FC]/50 border-t border-b border-[#075B91]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#073B66]/10 text-[#073B66] text-xs font-bold uppercase tracking-wider mb-4">
            <span className="w-2 h-2 rounded-full bg-[#258A48]" />
            <span>SOLUTIONS COMPLÈTES DE VOYAGE</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#073B66] tracking-tight mb-4">
            Nos services de voyage
          </h2>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Des solutions pour vous accompagner à chaque étape de votre voyage.
          </p>
        </div>

        {/* 2-Column Grid on Desktop & Tablet, 1-Column on Mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 items-start">
          {SERVICES_DATA.map((service, index) => {
            const Icon = serviceIcons[service.iconName] || PlaneTakeoff;
            const expanded = isExpanded(service.id);
            const isDeepBlueTheme = service.id === 'billets-avion' || service.id === 'circuits-touristiques';
            const isPaleBlueTheme = index % 2 === 1 && !isDeepBlueTheme;

            return (
              <div
                key={service.id}
                onMouseEnter={() => setHoveredCardId(service.id)}
                onMouseLeave={() => setHoveredCardId(null)}
                className={`group rounded-2xl transition-all duration-300 relative flex flex-col ${
                  isDeepBlueTheme
                    ? 'bg-[#073B66] text-white shadow-lg hover:shadow-2xl hover:shadow-[#073B66]/20 border border-[#075B91]'
                    : isPaleBlueTheme
                    ? 'bg-[#EAF5FC] text-[#102A43] shadow-md hover:shadow-xl border border-[#35A9E8]/30'
                    : 'bg-white text-[#102A43] shadow-sm hover:shadow-xl border border-slate-200/90'
                } hover:-translate-y-1`}
              >
                {/* Card Header & Collapsed Summary */}
                <div className="p-6 sm:p-7 flex-1">
                  <div className="flex items-start justify-between gap-4 mb-5">
                    {/* Icon Badge */}
                    <div
                      className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-105 ${
                        isDeepBlueTheme
                          ? 'bg-white/10 text-[#35A9E8] border border-white/20'
                          : 'bg-[#258A48]/10 text-[#258A48] border border-[#258A48]/20'
                      }`}
                    >
                      <Icon className="w-7 h-7" />
                    </div>

                    {/* Service Number & Expansion Toggle Button */}
                    <div className="flex items-center gap-3">
                      <span
                        className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                          isDeepBlueTheme
                            ? 'text-white/60 bg-white/10'
                            : 'text-slate-500 bg-slate-100'
                        }`}
                      >
                        {service.number}
                      </span>

                      {/* Expansion indicator button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLock(service.id);
                        }}
                        className={`p-2 rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#35A9E8] cursor-pointer ${
                          isDeepBlueTheme
                            ? 'text-white/80 hover:text-white hover:bg-white/10'
                            : 'text-slate-600 hover:text-[#073B66] hover:bg-slate-100'
                        }`}
                        aria-expanded={expanded}
                        aria-label={expanded ? `Réduire les détails de ${service.name}` : `Afficher les détails de ${service.name}`}
                        title={expanded ? 'Cliquer pour verrouiller/réduire' : 'Cliquer pour développer'}
                      >
                        <ChevronDown
                          className={`w-5 h-5 transition-transform duration-300 ${
                            expanded ? 'rotate-180 text-[#35A9E8]' : ''
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Service Title */}
                  <h3
                    className={`text-xl sm:text-2xl font-bold tracking-tight mb-2.5 ${
                      isDeepBlueTheme ? 'text-white' : 'text-[#073B66]'
                    }`}
                  >
                    {service.name}
                  </h3>

                  {/* Short Description */}
                  <p
                    className={`text-sm sm:text-base leading-relaxed ${
                      isDeepBlueTheme ? 'text-[#EAF5FC]/90' : 'text-slate-600'
                    }`}
                  >
                    {service.shortDescription}
                  </p>
                </div>

                {/* Expandable Downward Section */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                    expanded ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                  aria-hidden={!expanded}
                >
                  <div
                    className={`px-6 sm:px-7 pb-6 pt-2 border-t ${
                      isDeepBlueTheme ? 'border-white/15' : 'border-slate-200/80'
                    }`}
                  >
                    {/* Expanded Details Paragraph */}
                    <div
                      className={`text-sm leading-relaxed mb-4 p-3.5 rounded-xl ${
                        isDeepBlueTheme
                          ? 'bg-white/10 text-[#EAF5FC]'
                          : 'bg-white text-slate-700 border border-slate-100'
                      }`}
                    >
                      <p className="font-medium text-xs uppercase tracking-wider text-[#35A9E8] mb-1">
                        Détails & démarches :
                      </p>
                      {service.expandedDetails}
                    </div>

                    {/* Feature Highlights */}
                    {service.highlights && service.highlights.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-5">
                        {service.highlights.map((highlight, idx) => (
                          <div
                            key={idx}
                            className={`flex items-center gap-2 text-xs font-medium ${
                              isDeepBlueTheme ? 'text-[#EAF5FC]/85' : 'text-slate-600'
                            }`}
                          >
                            <span className="w-4 h-4 rounded-full bg-[#258A48]/20 text-[#258A48] flex items-center justify-center shrink-0">
                              <Check className="w-2.5 h-2.5" />
                            </span>
                            <span>{highlight}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Dedicated Service-Specific CTA Button */}
                    <div>
                      <button
                        type="button"
                        onClick={() => onSelectService(service.id)}
                        className={`w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold transition-all duration-200 cursor-pointer shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#35A9E8] ${
                          isDeepBlueTheme
                            ? 'bg-[#258A48] hover:bg-[#35A9E8] text-white'
                            : 'bg-[#073B66] hover:bg-[#258A48] text-white'
                        }`}
                      >
                        <span>{service.ctaText}</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Footer expansion cue on collapsed cards */}
                {!expanded && (
                  <div
                    onClick={() => toggleLock(service.id)}
                    className={`px-6 pb-4 pt-0 text-xs font-medium flex items-center gap-1.5 cursor-pointer ${
                      isDeepBlueTheme ? 'text-[#35A9E8]' : 'text-[#075B91]'
                    }`}
                  >
                    <span>Voir les détails et réserver</span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
