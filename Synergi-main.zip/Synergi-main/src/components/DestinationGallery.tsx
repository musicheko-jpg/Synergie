import React from 'react';
import { MapPin, ArrowUpRight } from 'lucide-react';
import parisImg from '../assets/images/destination_paris_1791865533552.jpg';
import dubaiImg from '../assets/images/destination_dubai_1791865533863.jpg';
import zanzibarImg from '../assets/images/destination_zanzibar_1791865562190.jpg';
import marrakechImg from '../assets/images/destination_marrakech_1791865562248.jpg';

interface DestinationGalleryProps {
  onSelectDestination: (destName: string) => void;
}

const DESTINATIONS = [
  {
    name: 'Paris',
    country: 'France',
    tagline: 'Culture, gastronomie et capitale européenne',
    image: parisImg,
  },
  {
    name: 'Dubaï',
    country: 'Émirats Arabes Unis',
    tagline: 'Modernité, shopping et carrefour international',
    image: dubaiImg,
  },
  {
    name: 'Zanzibar',
    country: 'Tanzanie',
    tagline: 'Plages turquoise, détente et lagons tropicaux',
    image: zanzibarImg,
  },
  {
    name: 'Marrakech',
    country: 'Maroc',
    tagline: 'Palais somptueux, médina et traditions',
    image: marrakechImg,
  },
];

export const DestinationGallery: React.FC<DestinationGalleryProps> = ({
  onSelectDestination,
}) => {
  return (
    <section id="destinations" className="py-20 bg-white border-t border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#075B91] mb-2">
              <MapPin className="w-3.5 h-3.5 text-[#258A48]" />
              <span>INSPIRATIONS DE SÉJOUR</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#073B66] tracking-tight">
              Des destinations à découvrir
            </h2>
          </div>
          <p className="text-sm text-slate-600 max-w-md">
            Des exemples de destinations prisées pour vos vacances, congrès ou voyages d'affaires à travers le monde.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {DESTINATIONS.map((dest) => (
            <div
              key={dest.name}
              className="group relative rounded-2xl overflow-hidden aspect-[3/4] bg-slate-900 shadow-md hover:shadow-xl transition-all duration-300"
            >
              {/* Background Photo */}
              <img
                src={dest.image}
                alt={`${dest.name}, ${dest.country}`}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
                referrerPolicy="no-referrer"
              />

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#073B66]/90 via-[#073B66]/35 to-transparent transition-opacity" />

              {/* Card Content Overlay */}
              <div className="absolute inset-0 p-5 flex flex-col justify-end text-white">
                <span className="text-xs font-semibold tracking-wide uppercase text-[#35A9E8] mb-1">
                  {dest.country}
                </span>
                <h3 className="text-xl font-bold text-white mb-1.5 leading-snug">
                  {dest.name}
                </h3>
                <p className="text-xs text-white/80 line-clamp-2 mb-3">
                  {dest.tagline}
                </p>

                <button
                  type="button"
                  onClick={() => onSelectDestination(dest.name)}
                  className="w-full inline-flex items-center justify-between text-xs font-semibold text-white bg-white/20 hover:bg-[#258A48] backdrop-blur-sm px-3.5 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  <span>Demander un devis pour {dest.name}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#35A9E8] group-hover:text-white" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
