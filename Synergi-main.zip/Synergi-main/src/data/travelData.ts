export interface ServiceItem {
  id: string;
  number: string;
  name: string;
  shortDescription: string;
  expandedDetails: string;
  ctaText: string;
  category: 'vols' | 'sejour' | 'formalites' | 'decouverte';
  iconName: string;
  highlights?: string[];
}

export interface DestinationItem {
  id: string;
  name: string;
  country: string;
  tagline: string;
  image: string;
  bestPeriod?: string;
}

export interface AirlinePartner {
  id: string;
  name: string;
  code: string;
  hub: string;
  alliance?: string;
  note: string;
}

export const AGENCY_CONTACT = {
  name: "Sinergy Travel and Business",
  tagline: "Des professionnels à votre service",
  location: "Yaoundé, Cameroun",
  address: "Centre d'Affaires, Yaoundé - Cameroun",
  phones: [
    { display: "+237 243 80 32 52", raw: "+237243803252" },
    { display: "+237 670 11 13 49", raw: "+237670111349" },
  ],
  whatsappNumber: "+237670111349",
  email: "sinergytravel@example.com",
  hours: "Lun - Ven : 08h00 - 18h00 | Sam : 09h00 - 14h00",
};

export const TRUST_HIGHLIGHTS = [
  {
    id: "assistance",
    title: "Assistance voyage",
    description: "Accompagnement continu avant, pendant et après vos déplacements.",
    icon: "Headset",
  },
  {
    id: "reservations",
    title: "Réservations de transport et d'hébergement",
    description: "Tarifs négociés sur les meilleures compagnies et hôtels sélectionnés.",
    icon: "Compass",
  },
  {
    id: "accompagnement",
    title: "Accompagnement personnalisé",
    description: "Conseils sur mesure adaptés à vos contraintes professionnelles et privées.",
    icon: "ShieldCheck",
  },
  {
    id: "circuits",
    title: "Organisation de circuits touristiques",
    description: "Itinéraires authentiques et découvertes inoubliables au Cameroun et à l'international.",
    icon: "MapPin",
  },
];

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "billets-avion",
    number: "01",
    name: "Billets d'avion",
    shortDescription: "Préparez vos déplacements vers vos destinations préférées.",
    expandedDetails: "Indiquez votre ville de départ, votre destination, vos dates de voyage et le nombre de passagers pour demander une assistance concernant votre billet d'avion.",
    ctaText: "Demander un billet d'avion",
    category: "vols",
    iconName: "PlaneTakeoff",
    highlights: ["Tarifs avantageux", "Gestion des modifications", "Assistance aéroport"],
  },
  {
    id: "reservation-vols",
    number: "02",
    name: "Réservation de vols",
    shortDescription: "Organisez vos vols selon votre itinéraire.",
    expandedDetails: "Précisez votre destination, vos dates et vos préférences pour demander des informations sur votre réservation de vol.",
    ctaText: "Préparer ma réservation de vol",
    category: "vols",
    iconName: "CalendarDays",
    highlights: ["Itinéraires multi-destinations", "Classes Éco, Affaires & Première", "Suivi en temps réel"],
  },
  {
    id: "reservation-hotels",
    number: "03",
    name: "Réservation d'hôtels",
    shortDescription: "Trouvez un hébergement adapté à votre séjour.",
    expandedDetails: "Indiquez votre destination, vos dates d'arrivée et de départ ainsi que le nombre de voyageurs pour demander une assistance concernant votre hébergement.",
    ctaText: "Demander une réservation d'hôtel",
    category: "sejour",
    iconName: "Building2",
    highlights: ["Hôtels vérifiés", "Options avec petit-déjeuner", "Emplacements stratégiques"],
  },
  {
    id: "assurance-voyage",
    number: "04",
    name: "Assurance voyage",
    shortDescription: "Renseignez-vous sur les solutions d'assurance pour votre séjour.",
    expandedDetails: "Précisez votre destination, la durée de votre voyage et le type de couverture recherché afin de demander des informations complémentaires.",
    ctaText: "Demander une assurance voyage",
    category: "formalites",
    iconName: "Shield",
    highlights: ["Couverture médicale & rapatriement", "Annulation de vol", "Perte de bagages"],
  },
  {
    id: "assistance-visa",
    number: "05",
    name: "Assistance visa et formalités",
    shortDescription: "Préparez vos démarches avant votre départ.",
    expandedDetails: "Indiquez votre destination et le type de démarche souhaité pour demander des renseignements sur les formalités applicables.",
    ctaText: "Préparer mes formalités visa",
    category: "formalites",
    iconName: "FileCheck2",
    highlights: ["Vérification des dossiers", "Prise de rendez-vous consulaires", "Accompagnement rigoureux"],
  },
  {
    id: "change-devises",
    number: "06",
    name: "Change de devises",
    shortDescription: "Préparez vos besoins de change avant votre voyage.",
    expandedDetails: "Précisez les devises concernées et le montant approximatif pour demander des renseignements sur le service.",
    ctaText: "Demander un service de change",
    category: "formalites",
    iconName: "Coins",
    highlights: ["Taux compétitifs", "Devises majeures (EUR, USD, GBP, etc.)", "Transaction sécurisée"],
  },
  {
    id: "location-vehicules",
    number: "07",
    name: "Location de véhicules",
    shortDescription: "Organisez vos déplacements à destination.",
    expandedDetails: "Indiquez votre destination, les dates souhaitées et le type de véhicule recherché pour demander des informations.",
    ctaText: "Demander une location de véhicule",
    category: "sejour",
    iconName: "Car",
    highlights: ["Véhicules avec ou sans chauffeur", "Berlines & SUV", "Assistance 24/7 sur route"],
  },
  {
    id: "circuits-touristiques",
    number: "08",
    name: "Circuits touristiques",
    shortDescription: "Découvrez des destinations et des expériences adaptées à vos envies.",
    expandedDetails: "Précisez votre destination, la durée du séjour, le nombre de participants et vos centres d'intérêt pour demander une proposition de circuit touristique.",
    ctaText: "Créer mon circuit touristique",
    category: "decouverte",
    iconName: "Map",
    highlights: ["Circuits culturels & safaris", "Guides locaux certifiés", "Expériences exclusives"],
  },
  {
    id: "voyages-noces",
    number: "09",
    name: "Voyages de noces",
    shortDescription: "Préparez une escapade inoubliable à deux.",
    expandedDetails: "Indiquez la destination souhaitée, la période du voyage et le style de séjour recherché pour demander une proposition personnalisée.",
    ctaText: "Organiser notre voyage de noces",
    category: "decouverte",
    iconName: "HeartHandshake",
    highlights: ["Attentions romantiques", "Stations balnéaires de prestige", "Itinéraires privés"],
  },
  {
    id: "evenementiel-tourisme",
    number: "10",
    name: "Événementiel et tourisme",
    shortDescription: "Préparez vos projets touristiques et événementiels.",
    expandedDetails: "Décrivez votre projet, le lieu, la date et le nombre de participants pour demander une assistance dans l'organisation.",
    ctaText: "Organiser mon événement",
    category: "decouverte",
    iconName: "Sparkles",
    highlights: ["Séminaires d'entreprises", "Délégations officielles", "Logistique de groupe"],
  },
];

export const AIRLINE_PARTNERS: AirlinePartner[] = [
  {
    id: "air-france",
    name: "Air France",
    code: "AF",
    hub: "Paris-Charles de Gaulle (CDG)",
    alliance: "SkyTeam",
    note: "Vols directs et correspondances vers l'Europe et les Amériques.",
  },
  {
    id: "brussels-airlines",
    name: "Brussels Airlines",
    code: "SN",
    hub: "Bruxelles-National (BRU)",
    alliance: "Star Alliance",
    note: "Liaisons régulières depuis Yaoundé et Douala vers l'Europe.",
  },
  {
    id: "qatar-airways",
    name: "Qatar Airways",
    code: "QR",
    hub: "Doha-Hamad (DOH)",
    alliance: "oneworld",
    note: "Connectivité premium vers l'Asie, le Moyen-Orient et l'Australie.",
  },
  {
    id: "ethiopian-airlines",
    name: "Ethiopian Airlines",
    code: "ET",
    hub: "Addis-Abeba-Bole (ADD)",
    alliance: "Star Alliance",
    note: "Le plus vaste réseau intra-africain et correspondances mondiales.",
  },
  {
    id: "royal-air-maroc",
    name: "Royal Air Maroc",
    code: "AT",
    hub: "Casablanca-Mohammed V (CMN)",
    alliance: "oneworld",
    note: "Passerelle privilégiée vers le Maghreb, l'Europe et l'Amérique du Nord.",
  },
  {
    id: "egyptair",
    name: "EgyptAir",
    code: "MS",
    hub: "Le Caire (CAI)",
    alliance: "Star Alliance",
    note: "Liaisons pratiques vers le Moyen-Orient, l'Afrique de l'Est et l'Europe.",
  },
  {
    id: "air-cote-divoire",
    name: "Air Côte d'Ivoire",
    code: "HF",
    hub: "Abidjan-Félix Houphouët-Boigny (ABJ)",
    alliance: "Régional",
    note: "Connexions rapides et fluides à travers l'Afrique de l'Ouest et Centrale.",
  },
];
