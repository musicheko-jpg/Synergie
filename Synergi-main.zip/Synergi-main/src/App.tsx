/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MessageCircle } from 'lucide-react';
import { Navbar } from './components/Navbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { TrustHighlights } from './components/TrustHighlights.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { DestinationGallery } from './components/DestinationGallery.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { AirlinePartnersSection } from './components/AirlinePartnersSection.tsx';
import { CallToActionSection } from './components/CallToActionSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { AGENCY_CONTACT } from './data/travelData.ts';

export default function App() {
  const scrollToContact = () => {
    const contactElement = document.querySelector('#contact');
    if (contactElement) {
      contactElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToServices = () => {
    const servicesElement = document.querySelector('#services');
    if (servicesElement) {
      servicesElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePlanTripClick = () => {
    scrollToContact();
  };

  const handleReserveFlightClick = () => {
    scrollToContact();
  };

  const handleDiscoverServicesClick = () => {
    scrollToServices();
  };

  const handleSelectService = (_serviceId: string) => {
    scrollToContact();
  };

  const handleSelectDestination = (_destName: string) => {
    scrollToContact();
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F8FA] text-[#102A43] relative">
      {/* 1. Sticky Navigation Bar */}
      <Navbar onPlanTripClick={handlePlanTripClick} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 2. Hero Section: Cinematic Airplane & Travel Experience */}
        <HeroSection
          onReserveFlightClick={handleReserveFlightClick}
          onDiscoverServicesClick={handleDiscoverServicesClick}
        />

        {/* 3. Trust and Service Highlights Strip */}
        <TrustHighlights />

        {/* 4. Introduction / About Sinergy Travel and Business */}
        <AboutSection onLearnMoreClick={scrollToServices} />

        {/* 5. Destination Inspiration Gallery */}
        <DestinationGallery onSelectDestination={handleSelectDestination} />

        {/* 6. Services Section: 10 Expandable Travel Services with Dedicated CTAs */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* 7. Airline Partners & Flight Connectivity */}
        <AirlinePartnersSection />

        {/* 8. Bottom Call To Action Banner */}
        <CallToActionSection onDiscussProjectClick={scrollToContact} />

        {/* 9. Contact Section: Phone numbers, WhatsApp, Email, Address & Hours */}
        <ContactSection />
      </main>

      {/* 10. Footer with Official Logo & Contact Coordinates */}
      <Footer onSelectService={handleSelectService} />

      {/* 11. Floating WhatsApp Quick Contact Button */}
      <a
        href={`https://wa.me/${AGENCY_CONTACT.whatsappNumber}?text=Bonjour%20Sinergy%20Travel,%20je%20souhaite%20des%20informations%20sur%20vos%20services.`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 bg-[#258A48] hover:bg-[#146438] text-white px-4 py-3 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200 group border border-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#258A48]"
        aria-label="Contacter Sinergy Travel sur WhatsApp"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="hidden sm:inline text-xs font-bold tracking-wide">
          WhatsApp direct
        </span>
      </a>
    </div>
  );
}
